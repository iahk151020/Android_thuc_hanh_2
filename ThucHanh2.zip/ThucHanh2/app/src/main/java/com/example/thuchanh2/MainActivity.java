package com.example.thuchanh2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

//    String language;
    Spinner spinner;
    Button saveBtn;
    ImageView flag;
    TextView lan;
    TextView textSample;
    SharedPreferences sp;
    ArrayAdapter<CharSequence> adaper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner =  (Spinner)findViewById(R.id.spiner);
        saveBtn = (Button)findViewById(R.id.saveBtn);
        flag = (ImageView)findViewById(R.id.image);
        lan = (TextView)findViewById(R.id.language);
        textSample = (TextView)findViewById(R.id.text_tuong_ung);
        sp = getSharedPreferences("language", MODE_PRIVATE);

        int languageType = sp.getInt("type", 1);
        System.out.println(languageType);

        if (languageType == 1){
            toVietnamese();
        } else{
            toEnglish();
        }

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String language = spinner.getSelectedItem().toString();
                if (language.equalsIgnoreCase("tiếng anh")){
                    SharedPreferences.Editor editor = sp.edit();
                    editor.putInt("type", 0);
                    editor.commit();
                    toEnglish();
                } else if (language.equalsIgnoreCase("vietnamese")){
                    SharedPreferences.Editor editor = sp.edit();
                    editor.putInt("type", 1);
                    editor.commit();
                    toVietnamese();
                }
            }
        });

    }

    public void toEnglish(){
        saveBtn.setText("Save");
        flag.setImageResource(R.drawable.img);
        lan.setText("Language");
        textSample.setText("Hello English");
        adaper = ArrayAdapter.createFromResource(this, R.array.language2, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
        spinner.setAdapter(adaper);
    }

    public void toVietnamese(){
        saveBtn.setText("Lưu");
        flag.setImageResource(R.drawable.img_1);
        lan.setText("Ngôn ngữ");
        textSample.setText("Xin chào tiếng việt");
        adaper = ArrayAdapter.createFromResource(this, R.array.language1, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
        spinner.setAdapter(adaper);
    }
}